package com.example.smarttasks.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.smarttasks.ui.screens.ConfirmScreen
import com.example.smarttasks.ui.screens.CreatePasswordScreen
import com.example.smarttasks.ui.screens.ForgotPasswordScreen
import com.example.smarttasks.ui.screens.VerifyCodeScreen
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@Composable
fun AppNavGraph() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "forgot_password"
    ) {
        // Screen 1: Forget Password
        composable("forgot_password") {
            ForgotPasswordScreen(
                onNextClicked = { email ->
                    val encodedEmail = URLEncoder.encode(email, StandardCharsets.UTF_8.toString())
                    navController.navigate("verify_code/$encodedEmail")
                }
            )
        }

        // Screen 2: Verify Code
        composable(
            route = "verify_code/{email}",
            arguments = listOf(navArgument("email") { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedEmail = backStackEntry.arguments?.getString("email") ?: ""
            val email = URLDecoder.decode(encodedEmail, StandardCharsets.UTF_8.toString())

            VerifyCodeScreen(
                email = email,
                onBackClicked = { navController.popBackStack() },
                onNextClicked = { otp ->
                    val encodedOtp = URLEncoder.encode(otp, StandardCharsets.UTF_8.toString())
                    navController.navigate("create_password/$encodedEmail/$encodedOtp")
                }
            )
        }

        // Screen 3: Create New Password
        composable(
            route = "create_password/{email}/{otp}",
            arguments = listOf(
                navArgument("email") { type = NavType.StringType },
                navArgument("otp") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val encodedEmail = backStackEntry.arguments?.getString("email") ?: ""
            val encodedOtp = backStackEntry.arguments?.getString("otp") ?: ""
            val email = URLDecoder.decode(encodedEmail, StandardCharsets.UTF_8.toString())
            val otp = URLDecoder.decode(encodedOtp, StandardCharsets.UTF_8.toString())

            CreatePasswordScreen(
                email = email,
                otp = otp,
                onBackClicked = { navController.popBackStack() },
                onNextClicked = { password ->
                    val encodedPassword = URLEncoder.encode(password, StandardCharsets.UTF_8.toString())
                    navController.navigate("confirm/$encodedEmail/$encodedOtp/$encodedPassword")
                }
            )
        }

        // Screen 4: Confirm & Data Flow Summary
        composable(
            route = "confirm/{email}/{otp}/{password}",
            arguments = listOf(
                navArgument("email") { type = NavType.StringType },
                navArgument("otp") { type = NavType.StringType },
                navArgument("password") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val encodedEmail = backStackEntry.arguments?.getString("email") ?: ""
            val encodedOtp = backStackEntry.arguments?.getString("otp") ?: ""
            val encodedPassword = backStackEntry.arguments?.getString("password") ?: ""

            val email = URLDecoder.decode(encodedEmail, StandardCharsets.UTF_8.toString())
            val otp = URLDecoder.decode(encodedOtp, StandardCharsets.UTF_8.toString())
            val password = URLDecoder.decode(encodedPassword, StandardCharsets.UTF_8.toString())

            ConfirmScreen(
                email = email,
                otp = otp,
                password = password,
                onBackClicked = { navController.popBackStack() },
                onSubmitSuccess = {
                    // Pop up to forgot_password and clear backstack
                    navController.navigate("forgot_password") {
                        popUpTo("forgot_password") { inclusive = true }
                    }
                }
            )
        }
    }
}
