package com.example.studentgradeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// 1. Tạo class Student gồm String name và Double? score
data class Student(
    val name: String,
    val score: Double?
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GradeSummaryApp()
        }
    }
}

// Hàm xếp loại dùng lại từ Bài 2
fun evaluateGrade(score: Double?): Pair<String, Color> {
    if (score == null) return "Chưa có điểm" to Color.Gray
    return if (score < 0 || score > 10) {
        "Không hợp lệ" to Color.Gray
    } else if (score >= 8.0) {
        "Giỏi" to Color(0xFF16A34A)        // Xanh lá
    } else if (score >= 6.5) {
        "Khá" to Color(0xFF2563EB)         // Xanh dương
    } else if (score >= 5.0) {
        "Trung bình" to Color(0xFFD97706)   // Cam/Vàng
    } else {
        "Yếu" to Color(0xFFDC2626)         // Đỏ
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradeSummaryApp() {
    // Dữ liệu mẫu: An 9.0 · Bình 7.2 · Chi (chưa có) · Dũng 4.5 · Em 5.8
    val studentList = listOf(
        Student("Nguyễn Văn An", 9.0),
        Student("Trần Thị Bình", 7.2),
        Student("Lê Minh Chi", null),
        Student("Phạm Quốc Dũng", 4.5),
        Student("Võ Thanh Em", 5.8)
    )

    // 3. Dùng vòng lặp for + if để tính các thông số
    var totalScore = 0.0
    var scoredStudentCount = 0
    var gioicount = 0
    var noScoreCount = 0
    var maxScore = 0.0

    for (student in studentList) {
        val score = student.score
        if (score == null) {
            noScoreCount++
        } else {
            totalScore += score
            scoredStudentCount++
            if (score >= 8.0) {
                gioicount++
            }
            if (score > maxScore) {
                maxScore = score
            }
        }
    }

    // Tính điểm trung bình (bỏ qua người chưa có điểm)
    val averageScore = if (scoredStudentCount > 0) totalScore / scoredStudentCount else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Bảng điểm lớp",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1E3A8A) // Xanh Navy
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF3F4F6))
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // --- BẢNG TỔNG QUAN ĐIỂM LỚP (CARD MÀU XANH ĐẬM) ---
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A8A))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "Điểm trung bình lớp",
                        color = Color.LightGray,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = String.format(Locale.US, "%.2f", averageScore),
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f))

                    Spacer(modifier = Modifier.height(12.dp))

                    // Dòng chỉ số thống kê
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Số HS Giỏi
                        Column {
                            Text(text = "Giỏi", color = Color.LightGray, fontSize = 11.sp)
                            Text(
                                text = "$gioicount",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Số HS Chưa có điểm
                        Column {
                            Text(text = "Chưa có điểm", color = Color.LightGray, fontSize = 11.sp)
                            Text(
                                text = "$noScoreCount",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Điểm Cao nhất
                        Column {
                            Text(text = "Cao nhất", color = Color.LightGray, fontSize = 11.sp)
                            Text(
                                text = String.format(Locale.US, "%.1f", maxScore),
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // --- DANH SÁCH SINH VIÊN ---
            Text(
                text = "DANH SÁCH - ${studentList.size} SINH VIÊN",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // 2. Dùng vòng lặp for để hiển thị tên, điểm, xếp loại
                    for ((index, student) in studentList.withIndex()) {
                        val (rankText, rankColor) = evaluateGrade(student.score)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Cột Tên và Xếp loại bên trái
                            Column {
                                Text(
                                    text = student.name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = rankText,
                                    fontSize = 12.sp,
                                    color = rankColor,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // Điểm số bên phải
                            Text(
                                text = student.score?.let { String.format(Locale.US, "%.1f", it) } ?: "—",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }

                        // Đường gạch ngang phân cách giữa các dòng
                        if (index < studentList.size - 1) {
                            HorizontalDivider(color = Color(0xFFF3F4F6))
                        }
                    }
                }
            }
        }
    }
}