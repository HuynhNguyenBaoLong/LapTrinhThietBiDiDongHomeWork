package com.example.studentlistapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudentListApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentListApp() {
    // 1. Tạo danh sách 5 sinh viên mẫu (có null)
    val studentList = listOf(
        Student("Nguyễn Văn An", "an@sv.edu.vn", "0901 234 567"),
        Student("Trần Thị Bình", null, "0912 888 999"),
        Student("Lê Minh Chi", "chi@sv.edu.vn", null),
        Student("Phạm Quốc Dũng", null, null),
        Student("Võ Thanh Em", "em@sv.edu.vn", "0933 111 222")
    )

    // 2. Dùng vòng lặp for đếm số sinh viên thiếu email
    var missingEmailCount = 0
    for (student in studentList) {
        if (student.email == null) {
            missingEmailCount++
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Danh sách sinh viên",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1E3A8A)
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF3F4F6))
        ) {
            // Danh sách thẻ sinh viên (Cho phép cuộn)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // 3. Dùng vòng lặp for để tạo các thẻ sinh viên
                for (student in studentList) {
                    StudentCard(student = student)
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Thanh tổng kết ở cuối danh sách
            FooterSummary(
                totalStudents = studentList.size,
                missingEmailCount = missingEmailCount
            )
        }
    }
}

@Composable
fun StudentCard(student: Student) {
    // 4. Dùng toán tử Elvis ?: để xử lý null
    val displayEmail = student.email ?: "Chưa cập nhật"
    val displayPhone = student.phone ?: "Chưa cập nhật"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = student.name,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Email
            Row {
                Text(text = "Email: ", fontSize = 13.sp, color = Color.Gray)
                Text(
                    text = displayEmail,
                    fontSize = 13.sp,
                    color = if (student.email == null) Color(0xFFB91C1C) else Color.Gray,
                    fontStyle = if (student.email == null) FontStyle.Italic else FontStyle.Normal
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // SĐT
            Row {
                Text(text = "SĐT: ", fontSize = 13.sp, color = Color.Gray)
                Text(
                    text = displayPhone,
                    fontSize = 13.sp,
                    color = if (student.phone == null) Color(0xFFB91C1C) else Color.Gray,
                    fontStyle = if (student.phone == null) FontStyle.Italic else FontStyle.Normal
                )
            }
        }
    }
}

@Composable
fun FooterSummary(totalStudents: Int, missingEmailCount: Int) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row {
                Text(text = "Tổng: ", fontSize = 14.sp, color = Color.Black)
                Text(
                    text = "$totalStudents sinh viên",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }

            Row {
                Text(text = "Thiếu email: ", fontSize = 14.sp, color = Color.Black)
                Text(
                    text = "$missingEmailCount",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB91C1C)
                )
            }
        }
    }
}