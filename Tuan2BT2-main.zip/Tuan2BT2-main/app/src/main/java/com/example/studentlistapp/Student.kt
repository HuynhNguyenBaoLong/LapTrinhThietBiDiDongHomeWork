package com.example.studentlistapp

data class Student(
    val name: String,
    val email: String?,
    val phone: String?
)
