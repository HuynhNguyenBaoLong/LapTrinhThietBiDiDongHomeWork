package com.example.xeploaihocluc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GradeEvaluationApp()
        }
    }
}

// Hàm nhận vào điểm và trả về cặp (Xếp loại, Màu sắc)
fun evaluateGrade(score: Double): Pair<String, Color> {
    return if (score !in 0.0..10.0) {
        "Không hợp lệ" to Color(0xFF6B7280)
    } else if (score >= 8.0) {
        "Giỏi" to Color(0xFF16A34A)
    } else if (score >= 6.5) {
        "Khá" to Color(0xFF2563EB)
    } else if (score >= 5.0) {
        "Trung bình" to Color(0xFFD97706)
    } else {
        "Yếu" to Color(0xFFDC2626)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradeEvaluationApp() {
    // 1. Khai báo điểm chính (8.5)
    val mainScore = 8.5
    val (mainRank, mainColor) = evaluateGrade(mainScore)

    // 4. Danh sách các điểm cần kiểm tra thêm: 9, 7, 5.5, 3 và 11
    val testScores = listOf(9.0, 7.0, 5.5, 3.0, 11.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Xếp loại học lực",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1E3A8A)
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF3F4F6))
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // --- KHU VỰC HIỂN THỊ ĐIỂM CHÍNH (8.5) ---
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Điểm trung bình",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "$mainScore",
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Container hiển thị xếp loại
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = mainColor.copy(alpha = 0.1f)
                        )
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mainRank,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = mainColor
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // --- KHU VỰC KIỂM TRA THÊM ---
            Text(
                text = "KIỂM TRA THÊM",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    for ((index, score) in testScores.withIndex()) {
                        val (rank, color) = evaluateGrade(score)
                        val formattedScore = if (score % 1.0 == 0.0) score.toInt().toString() else score.toString()

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Điểm $formattedScore",
                                fontSize = 14.sp,
                                color = Color.Black
                            )

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = color.copy(alpha = 0.1f)
                            ) {
                                Text(
                                    text = rank,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = color,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        if (index < testScores.size - 1) {
                            HorizontalDivider(color = Color(0xFFF3F4F6))
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun GradeEvaluationAppPreview() {
    GradeEvaluationApp()
}